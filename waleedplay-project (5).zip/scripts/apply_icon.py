"""Apply a custom launcher icon to the generated Capacitor Android project.

Usage: python3 scripts/apply_icon.py [icon.png] [android/app/src/main/res] [#background]
To change the icon later, just replace assets/icon-only.png and push.
"""
import os, sys
from PIL import Image

icon_path = sys.argv[1] if len(sys.argv) > 1 else "assets/icon-only.png"
res = sys.argv[2] if len(sys.argv) > 2 else "android/app/src/main/res"
bg = (sys.argv[3] if len(sys.argv) > 3 else "#090C14").upper()

if not os.path.isfile(icon_path):
    sys.exit(f"ERROR: icon not found: {icon_path}")
if not os.path.isdir(res):
    sys.exit(f"ERROR: res folder not found: {res} (run 'npx cap add android' first)")

src = Image.open(icon_path).convert("RGBA")
side = min(src.size)                      # center-crop to a square
src = src.crop(((src.width - side) // 2, (src.height - side) // 2,
                (src.width + side) // 2, (src.height + side) // 2))

LEGACY = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
ADAPT  = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}
bg_rgb = tuple(int(bg[i:i + 2], 16) for i in (1, 3, 5))

def round_mask(n):
    from PIL import ImageDraw
    m = Image.new("L", (n * 4, n * 4), 0)
    ImageDraw.Draw(m).ellipse((0, 0, n * 4 - 1, n * 4 - 1), fill=255)
    return m.resize((n, n), Image.LANCZOS)

count = 0
for d, n in LEGACY.items():
    folder = os.path.join(res, f"mipmap-{d}")
    os.makedirs(folder, exist_ok=True)
    flat = src.resize((n, n), Image.LANCZOS)
    flat.save(os.path.join(folder, "ic_launcher.png"))
    r = flat.copy(); r.putalpha(round_mask(n))
    r.save(os.path.join(folder, "ic_launcher_round.png"))
    # adaptive foreground: icon shrunk to the 66% safe zone
    a = ADAPT[d]; inner = int(a * 0.66)
    fg = Image.new("RGBA", (a, a), (0, 0, 0, 0))
    fg.paste(src.resize((inner, inner), Image.LANCZOS), ((a - inner) // 2, (a - inner) // 2))
    fg.save(os.path.join(folder, "ic_launcher_foreground.png"))
    count += 3

# adaptive icon definitions + background colour
any_dir = os.path.join(res, "mipmap-anydpi-v26"); os.makedirs(any_dir, exist_ok=True)
xml = ('<?xml version="1.0" encoding="utf-8"?>\n'
       '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
       '  <background android:drawable="@color/ic_launcher_background"/>\n'
       '  <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n'
       '</adaptive-icon>\n')
for name in ("ic_launcher.xml", "ic_launcher_round.xml"):
    open(os.path.join(any_dir, name), "w").write(xml)
vals = os.path.join(res, "values"); os.makedirs(vals, exist_ok=True)
open(os.path.join(vals, "ic_launcher_background.xml"), "w").write(
    f'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n  <color name="ic_launcher_background">{bg}</color>\n</resources>\n')

# remove old vector foreground/background drawables that could shadow the new icon
for old in ("drawable-v24/ic_launcher_foreground.xml", "drawable/ic_launcher_background.xml"):
    p = os.path.join(res, old)
    if os.path.exists(p):
        os.remove(p); print("removed", old)

print(f"OK: wrote {count} icon files from {icon_path} into {res}")
