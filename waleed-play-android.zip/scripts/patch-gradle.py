import re, os
p = "android/app/build.gradle"
s = open(p, encoding="utf-8").read()
s = re.sub(r"versionCode\s+\d+", "versionCode " + os.environ.get("GITHUB_RUN_NUMBER", "1"), s, 1)
if os.environ.get("KS_PATH"):
    sc = """    signingConfigs {
        release {
            storeFile file(System.getenv("KS_PATH"))
            storePassword System.getenv("KS_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS")
            keyPassword System.getenv("KEY_PASSWORD")
        }
    }
"""
    s = s.replace("android {\n", "android {\n" + sc, 1)
    s = re.sub(r"(buildTypes\s*\{\s*release\s*\{)", r"\1\n            signingConfig signingConfigs.release", s, 1)
open(p, "w", encoding="utf-8").write(s)
print(s)
