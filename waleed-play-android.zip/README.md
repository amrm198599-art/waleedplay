# وليد بلاي (Waleed Play)

تطبيق أندرويد (Capacitor) لتجهيز صور تطبيقات جوجل بلاي: الأيقونة 512×512 وصورة الواجهة 1024×500 ولقطات الشاشة، مع تقصير الروابط. الواجهة عربي/English ونهاري/ليلي.

## التشغيل على GitHub
1. أنشئ مستودع جديد وارفع محتوى هذا المجلد إليه (الفرع `main`).
2. افتح تبويب **Actions** وانتظر انتهاء **Build Android (APK + AAB)**، أو شغّله يدويًا من **Run workflow**.
3. من صفحة التشغيل نزّل الملفات من **Artifacts**:
   - `waleed-play-debug-apk`: ملف APK للتجربة على الموبايل.
   - `waleed-play-release`: ملف APK وAAB موقّعين للرفع على جوجل بلاي (يظهر فقط بعد إضافة مفتاح التوقيع).

## مفتاح التوقيع (لازم لملف AAB الخاص بالنشر)
أنشئ المفتاح مرة واحدة واحتفظ به في مكان آمن (لو ضاع لن تقدر تحدّث التطبيق بنفس التوقيع):

```
keytool -genkeypair -v -keystore release.jks -alias waleedplay -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks
```

ثم أضف في **Settings > Secrets and variables > Actions** هذه الأسرار:

| الاسم | القيمة |
|---|---|
| `KEYSTORE_BASE64` | ناتج أمر base64 |
| `KEYSTORE_PASSWORD` | كلمة سر الملف |
| `KEY_ALIAS` | `waleedplay` |
| `KEY_PASSWORD` | كلمة سر المفتاح |

رقم الإصدار (versionCode) بيزيد تلقائيًا مع كل تشغيل.

## تعديلات
- الواجهة كلها في `www/index.html`.
- معرّف التطبيق واسمه في `capacitor.config.json` (`com.waleedplay.app`). غيّره قبل أول رفع على جوجل بلاي لأنه لا يتغير بعدها.
- أيقونة التطبيق الافتراضية هي أيقونة Capacitor. لتغييرها استبدل ملفات `mipmap-*` داخل `android/app/src/main/res` أو استخدم أداة `@capacitor/assets`.

## الأيقونة
أيقونة التطبيق (تاج ذهبي وحرف W على خلفية زرقاء) موجودة في `resources/android/res` وبتتطبق تلقائيًا أثناء البناء. نسخة 512×512 لصفحة المتجر في `store/icon-512x512.png`.
